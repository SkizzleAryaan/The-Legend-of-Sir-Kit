// DAC.h


#ifndef DAC_H
#define DAC_H
void DAC_Init(void);


void DAC_Out(uint32_t data);

#endif

