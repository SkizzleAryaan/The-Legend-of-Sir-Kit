// Song.c
// Lab 6 Extra credit 1) 
// playing your favorite song.
//
// For use with the TM4C123
// ECE319K lab6 extra credit 1)
// Program written by: put your names here
// 1/2/23

#include "Sound.h"
#include "../inc/DAC.h"
#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts

void Song_Init(void){
  // extra credit 1)

}

// Play song, while button pushed or until end
void Song_Play(void){
  // extra credit 1)

}

// Stop song
void Song_Stop(void){
 // if needed
}

