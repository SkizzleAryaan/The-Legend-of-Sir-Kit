// SpaceInvaders.c
// Runs on TM4C123
// Jonathan Valvano and Daniel Valvano
// This is a starter project for the ECE319K Lab 10

// Last Modified: 1/2/2023 
// http://www.spaceinvaders.de/
// sounds at http://www.classicgaming.cc/classics/spaceinvaders/sounds.php
// http://www.classicgaming.cc/classics/spaceinvaders/playguide.php

// ******* Possible Hardware I/O connections*******************
// Slide pot pin 1 connected to ground
// Slide pot pin 2 connected to PD2/AIN5
// Slide pot pin 3 connected to +3.3V 
// buttons connected to PE0-PE3
// 32*R resistor DAC bit 0 on PB0 (least significant bit)
// 16*R resistor DAC bit 1 on PB1
// 8*R resistor DAC bit 2 on PB2 
// 4*R resistor DAC bit 3 on PB3
// 2*R resistor DAC bit 4 on PB4
// 1*R resistor DAC bit 5 on PB5 (most significant bit)
// LED on PD1
// LED on PD0


#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "../inc/ST7735.h"
#include "Random.h"
#include "TExaS.h"
#include "../inc/ADC.h"
#include "Images.h"
#include "../inc/wave.h"
#include "Timer1.h"



void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void Delay100ms(uint32_t count); // time delay in 0.1 seconds


typedef enum {left, right, idle, upatk} walking_t; 
typedef enum {FALSE, TRUE} bool;
typedef enum {Saxena, Agrawal} person; 
 
struct Player{ 
	int16_t x, y; 
	int8_t w, h; 
	bool atk; 
	walking_t motion; 	
	int8_t health; 
	person type; 
};

typedef struct Player player_t; 
int8_t dx = 2; 

const uint16_t *Left[2] = {left1, left2};
const uint16_t *Right[2] = {right1, right2};
player_t MainCharacter = {22, 159, 16, 16, FALSE, left, Agrawal}; 
int8_t anim = 0; 

void MoveLeft(void);
void MoveRight(void);

void PortF_Init(void){
  SYSCTL_RCGCGPIO_R |= 0x20;      // activate port F
  while((SYSCTL_PRGPIO_R&0x20) != 0x20){};
  GPIO_PORTF_DIR_R |=  0x0E;   // output on PF3,2,1 (built-in LED)
  GPIO_PORTF_PUR_R |= 0x10;
  GPIO_PORTF_DEN_R |=  0x1E;   // enable digital I/O on PF
}

void PortE_Init(void){
  SYSCTL_RCGCGPIO_R |= 0x10;      // activate port F
  while((SYSCTL_PRGPIO_R&0x10) != 0x10){};
  GPIO_PORTE_DIR_R &=  ~0x03;   // output on PFE,1, 0 (built-in LED)
  //GPIO_PORTE_PUR_R |= 0x10;
  GPIO_PORTE_DEN_R |=  0x03;   // enable digital I/O on PF
}

void Timer3A_Init(uint32_t period, uint32_t priority){
  volatile uint32_t delay;
  SYSCTL_RCGCTIMER_R |= 0x08;   // 0) activate TIMER3
  delay = SYSCTL_RCGCTIMER_R;         // user function
  TIMER3_CTL_R = 0x00000000;    // 1) disable timer2A during setup
  TIMER3_CFG_R = 0x00000000;    // 2) configure for 32-bit mode
  TIMER3_TAMR_R = 0x00000002;   // 3) configure for periodic mode, default down-count settings
  TIMER3_TAILR_R = period-1;    // 4) reload value
  TIMER3_TAPR_R = 0;            // 5) bus clock resolution
  TIMER3_ICR_R = 0x00000001;    // 6) clear timer2A timeout flag
  TIMER3_IMR_R = 0x00000001;    // 7) arm timeout interrupt
  NVIC_PRI8_R = (NVIC_PRI8_R&0x00FFFFFF)|(priority<<29); // priority  
// interrupts enabled in the main program after all devices initialized
// vector number 39, interrupt number 23
  NVIC_EN1_R = 1<<(35-32);      // 9) enable IRQ 35 in NVIC
  TIMER3_CTL_R = 0x00000001;    // 10) enable timer3A
}

void Timer3A_Stop(void){
  NVIC_DIS1_R = 1<<(35-32);   // 9) disable interrupt 35 in NVIC
  TIMER3_CTL_R = 0x00000000;  // 10) disable timer3
}



uint32_t ADCdata; 
uint32_t ADCflag;  

void Draw(player_t p); 

void Timer3A_Handler(void){
  TIMER3_ICR_R = TIMER_ICR_TATOCINT;// acknowledge TIMER2A timeout
  // write this
	GPIO_PORTF_DATA_R ^= 0x08; // toggle PF1
  ADCdata = ADC_In();      // Sample ADC
  ADCflag = 1;  
	//MoveLeft(); 
	if (ADCdata <= 1500) 
			 {
				 MoveLeft(); 
			 }
			 else if (ADCdata >= 2500) 
			 {
				 MoveRight(); 
			 }
			 else 
			 {
				 MainCharacter.motion = idle; 
			 }
	//Draw(MainCharacter); 
}


void Timer1A_Handler(void){ // can be used to perform tasks in background
  TIMER1_ICR_R = TIMER_ICR_TATOCINT;// acknowledge TIMER1A timeout
   // execute user task
}








void Draw(player_t p) {
	if (p.motion == left) 
	{
		ST7735_DrawBitmap(p.x, p.y, Left[anim], p.w, p.h); 
		anim++; 
		if (anim > 1) 
		{
			anim = 0; 
		}
	}
	else if (p.motion == right) 
	{
		ST7735_DrawBitmap(p.x, p.y, Right[anim], p.w, p.h); 
		anim++; 
		if (anim > 1) 
		{
			anim = 0; 
		}
	}
	else if (p.motion == idle) 
	{
		ST7735_DrawBitmap(p.x, p.y, front, p.w, p.h); 
	}
	 
}

void MoveLeft(void) 
{
	if (MainCharacter.x >=0)
	{
		MainCharacter.x -= dx;
	} 
	MainCharacter.motion = left; 
}

void MoveRight(void) 
{
	if (MainCharacter.x <=112)
	{
		MainCharacter.x += dx;
	} 
	MainCharacter.motion = right; 
}

int main(void){
  DisableInterrupts(); 
  TExaS_Init(NONE);       // Bus clock is 80 MHz 
	ADC_Init(); 
	Timer3A_Init(8000000, 0);
	PortF_Init();
	ST7735_InitR(INITR_REDTAB);
	TExaS_Init(SCOPE);         // Bus clock is 80 MHz 
	PortE_Init(); 
	
  Random_Init(1);

  Output_Init();
  ST7735_FillScreen(0x0000);            // set screen to black
  
  //ST7735_DrawBitmap(22, 159, Aryaan, 16,16); // player ship bottom
	
	EnableInterrupts();



  while(1)
	{
		Draw(MainCharacter); 
 }

}





// You can't use this timer, it is here for starter code only 
// you must use interrupts to perform delays
void Delay100ms(uint32_t count){uint32_t volatile time;
  while(count>0){
    time = 727240;  // 0.1sec at 80 MHz
    while(time){
      time--;
    }
    count--;
  }
}
typedef enum {English, Spanish, Portuguese, French} Language_t;
Language_t myLanguage=English;
typedef enum {HELLO, GOODBYE, LANGUAGE} phrase_t;
const char Hello_English[] ="Hello";
const char Hello_Spanish[] ="\xADHola!";
const char Hello_Portuguese[] = "Ol\xA0";
const char Hello_French[] ="All\x83";
const char Goodbye_English[]="Goodbye";
const char Goodbye_Spanish[]="Adi\xA2s";
const char Goodbye_Portuguese[] = "Tchau";
const char Goodbye_French[] = "Au revoir";
const char Language_English[]="English";
const char Language_Spanish[]="Espa\xA4ol";
const char Language_Portuguese[]="Portugu\x88s";
const char Language_French[]="Fran\x87" "ais";
const char *Phrases[3][4]={
  {Hello_English,Hello_Spanish,Hello_Portuguese,Hello_French},
  {Goodbye_English,Goodbye_Spanish,Goodbye_Portuguese,Goodbye_French},
  {Language_English,Language_Spanish,Language_Portuguese,Language_French}
};

int main1(void){ char l;
  DisableInterrupts();
  TExaS_Init(NONE);       // Bus clock is 80 MHz 
  Output_Init();
  ST7735_FillScreen(0x0000);            // set screen to black
  for(phrase_t myPhrase=HELLO; myPhrase<= GOODBYE; myPhrase++){
    for(Language_t myL=English; myL<= French; myL++){
         ST7735_OutString((char *)Phrases[LANGUAGE][myL]);
      ST7735_OutChar(' ');
         ST7735_OutString((char *)Phrases[myPhrase][myL]);
      ST7735_OutChar(13);
    }
  }
  Delay100ms(30);
  ST7735_FillScreen(0x0000);       // set screen to black
  l = 128;
  while(1){
    Delay100ms(20);
    for(int j=0; j < 3; j++){
      for(int i=0;i<16;i++){
        ST7735_SetCursor(7*j+0,i);
        ST7735_OutUDec(l);
        ST7735_OutChar(' ');
        ST7735_OutChar(' ');
        ST7735_SetCursor(7*j+4,i);
        ST7735_OutChar(l);
        l++;
      }
    }
  }  
}

